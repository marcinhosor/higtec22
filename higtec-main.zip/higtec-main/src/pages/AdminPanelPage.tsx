import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Shield, Webhook, CreditCard, ExternalLink, CheckCircle, AlertCircle,
  Users, Building2, Search, RefreshCw, Crown, Eye, Lock, KeyRound, Save,
  Smartphone, Monitor, Briefcase, ClipboardList, MapPin, Calendar,
} from "lucide-react";
import { toast } from "sonner";

interface CompanyRow {
  id: string;
  name: string;
  cnpj: string | null;
  email: string | null;
  phone: string | null;
  city: string | null;
  state: string | null;
  plan_tier: string;
  created_at: string;
  updated_at: string;
}

interface MemberRow {
  id: string;
  user_id: string;
  role: string;
  created_at: string;
  company_id: string;
  profile?: {
    full_name: string | null;
    phone: string | null;
    avatar_url: string | null;
  };
  company?: {
    name: string;
  };
}

export default function AdminPanelPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  // Password gate states
  const [hasPassword, setHasPassword] = useState<boolean | null>(null);
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [passwordInput, setPasswordInput] = useState("");
  const [verifyingPassword, setVerifyingPassword] = useState(false);
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [settingPassword, setSettingPassword] = useState(false);
  const [showChangePassword, setShowChangePassword] = useState(false);

  // Recovery states
  const [showRecovery, setShowRecovery] = useState(false);
  const [recoveryAuthPassword, setRecoveryAuthPassword] = useState("");
  const [recoveryNewPassword, setRecoveryNewPassword] = useState("");
  const [recoveryConfirmPassword, setRecoveryConfirmPassword] = useState("");
  const [recovering, setRecovering] = useState(false);

  // Data states
  const [companies, setCompanies] = useState<CompanyRow[]>([]);
  const [members, setMembers] = useState<MemberRow[]>([]);
  const [loadingData, setLoadingData] = useState(false);
  const [searchCompany, setSearchCompany] = useState("");
  const [searchMember, setSearchMember] = useState("");

  // Device sessions state
  interface DeviceSessionRow {
    id: string;
    company_id: string;
    user_id: string;
    device_id: string;
    device_type: string;
    device_name: string | null;
    is_active: boolean;
    last_active_at: string;
    created_at: string;
  }
  const [deviceSessions, setDeviceSessions] = useState<DeviceSessionRow[]>([]);
  const [searchDevice, setSearchDevice] = useState("");

  // Company stats
  const [collaboratorCounts, setCollaboratorCounts] = useState<Record<string, number>>({});
  const [serviceExecutionCounts, setServiceExecutionCounts] = useState<Record<string, number>>({});
  const [selectedCompany, setSelectedCompany] = useState<CompanyRow | null>(null);

  useEffect(() => {
    if (!user) return;
    supabase
      .rpc("is_master_admin" as any, { _user_id: user.id })
      .then(({ data }) => {
        setIsAdmin(!!data);
        setLoading(false);
        if (!data) {
          navigate("/");
        }
      });
  }, [user, navigate]);

  // Check if admin password exists
  useEffect(() => {
    if (!isAdmin) return;
    supabase.rpc("has_admin_password").then(({ data }) => {
      setHasPassword(!!data);
      if (!data) setIsUnlocked(true); // No password set yet, allow access to set one
    });
  }, [isAdmin]);

  useEffect(() => {
    if (isAdmin && isUnlocked) loadAllData();
  }, [isAdmin, isUnlocked]);

  const handleVerifyPassword = async () => {
    if (!passwordInput.trim()) return;
    setVerifyingPassword(true);
    const { data, error } = await supabase.rpc("verify_admin_password", { _password: passwordInput });
    if (error || !data) {
      toast.error("Senha incorreta");
    } else {
      setIsUnlocked(true);
      toast.success("Acesso liberado");
    }
    setPasswordInput("");
    setVerifyingPassword(false);
  };

  const handleRecoverPassword = async () => {
    if (!user?.email || !recoveryAuthPassword.trim()) {
      toast.error("Informe sua senha de login");
      return;
    }
    if (recoveryNewPassword.length < 6) {
      toast.error("A nova senha deve ter pelo menos 6 caracteres");
      return;
    }
    if (recoveryNewPassword !== recoveryConfirmPassword) {
      toast.error("As senhas não coincidem");
      return;
    }
    setRecovering(true);
    // Re-authenticate with Supabase Auth to prove identity
    const { error: authError } = await supabase.auth.signInWithPassword({
      email: user.email,
      password: recoveryAuthPassword,
    });
    if (authError) {
      toast.error("Senha de login incorreta");
      setRecovering(false);
      return;
    }
    // Now reset the admin password
    const { data, error } = await supabase.rpc("set_admin_password", { _password: recoveryNewPassword });
    if (error || !data) {
      toast.error("Erro ao redefinir senha do painel");
    } else {
      toast.success("Senha do painel redefinida com sucesso!");
      setHasPassword(true);
      setIsUnlocked(true);
      setShowRecovery(false);
      setRecoveryAuthPassword("");
      setRecoveryNewPassword("");
      setRecoveryConfirmPassword("");
    }
    setRecovering(false);
  };

  const handleSetPassword = async () => {
    if (newPassword.length < 6) {
      toast.error("A senha deve ter pelo menos 6 caracteres");
      return;
    }
    if (newPassword !== confirmPassword) {
      toast.error("As senhas não coincidem");
      return;
    }
    setSettingPassword(true);
    const { data, error } = await supabase.rpc("set_admin_password", { _password: newPassword });
    if (error || !data) {
      toast.error("Erro ao definir senha");
    } else {
      toast.success("Senha do painel admin definida com sucesso!");
      setHasPassword(true);
      setNewPassword("");
      setConfirmPassword("");
      setShowChangePassword(false);
    }
    setSettingPassword(false);
  };

  const loadAllData = async () => {
    setLoadingData(true);
    try {
      const [companiesRes, membersRes, devicesRes, collaboratorsRes, executionsRes] = await Promise.all([
        supabase.from("companies").select("*").order("created_at", { ascending: false }),
        supabase.from("company_memberships").select("*, profiles:user_id(full_name, phone, avatar_url)").order("created_at", { ascending: false }),
        supabase.from("device_sessions").select("*").order("last_active_at", { ascending: false }),
        supabase.from("collaborators").select("id, company_id"),
        supabase.from("service_executions").select("id, company_id"),
      ]);

      if (companiesRes.data) setCompanies(companiesRes.data as CompanyRow[]);
      if (membersRes.data) {
        const mapped = (membersRes.data as any[]).map((m) => ({
          ...m,
          profile: m.profiles || null,
        }));
        setMembers(mapped);
      }
      if (devicesRes.data) setDeviceSessions(devicesRes.data as any);

      // Build counts by company
      if (collaboratorsRes.data) {
        const counts: Record<string, number> = {};
        collaboratorsRes.data.forEach((c: any) => {
          counts[c.company_id] = (counts[c.company_id] || 0) + 1;
        });
        setCollaboratorCounts(counts);
      }
      if (executionsRes.data) {
        const counts: Record<string, number> = {};
        executionsRes.data.forEach((e: any) => {
          counts[e.company_id] = (counts[e.company_id] || 0) + 1;
        });
        setServiceExecutionCounts(counts);
      }
    } catch (err) {
      console.error("Error loading admin data:", err);
      toast.error("Erro ao carregar dados");
    }
    setLoadingData(false);
  };

  // Mercado Pago credentials state
  const [mpAccessToken, setMpAccessToken] = useState("");
  const [mpPublicKey, setMpPublicKey] = useState("");
  const [mpAccessTokenPreview, setMpAccessTokenPreview] = useState("");
  const [mpPublicKeyPreview, setMpPublicKeyPreview] = useState("");
  const [mpAccessTokenSet, setMpAccessTokenSet] = useState(false);
  const [mpPublicKeySet, setMpPublicKeySet] = useState(false);
  const [savingCredentials, setSavingCredentials] = useState(false);

  const projectId = import.meta.env.VITE_SUPABASE_PROJECT_ID;
  const webhookUrl = `https://${projectId}.supabase.co/functions/v1/mercadopago-webhook`;

  const copyWebhookUrl = () => {
    navigator.clipboard.writeText(webhookUrl);
    toast.success("URL do webhook copiada!");
  };

  // Load current credential status
  useEffect(() => {
    if (!isAdmin) return;
    supabase.functions
      .invoke("update-mp-credentials", { body: { action: "get" } })
      .then(({ data, error }) => {
        if (data && !error) {
          setMpAccessTokenSet(data.access_token_set);
          setMpAccessTokenPreview(data.access_token_preview || "");
          setMpPublicKeySet(data.public_key_set);
          setMpPublicKeyPreview(data.public_key_preview || "");
        }
      });
  }, [isAdmin]);

  const saveCredentials = async () => {
    if (!mpAccessToken && !mpPublicKey) {
      toast.error("Preencha pelo menos um campo");
      return;
    }
    setSavingCredentials(true);
    try {
      const { data, error } = await supabase.functions.invoke("update-mp-credentials", {
        body: {
          access_token: mpAccessToken || undefined,
          public_key: mpPublicKey || undefined,
        },
      });
      if (error) {
        toast.error("Erro ao salvar credenciais");
      } else if (data?.error) {
        toast.error(data.error);
      } else {
        toast.success("Credenciais salvas com sucesso!");
        setMpAccessToken("");
        setMpPublicKey("");
        // Reload credential status
        const { data: updated } = await supabase.functions.invoke("update-mp-credentials", {
          body: { action: "get" },
        });
        if (updated) {
          setMpAccessTokenSet(updated.access_token_set);
          setMpAccessTokenPreview(updated.access_token_preview || "");
          setMpPublicKeySet(updated.public_key_set);
          setMpPublicKeyPreview(updated.public_key_preview || "");
        }
      }
    } catch {
      toast.error("Erro ao salvar credenciais");
    }
    setSavingCredentials(false);
  };

  const handleChangePlan = async (companyId: string, newTier: 'free' | 'pro' | 'premium') => {
    const { error } = await supabase
      .from("companies")
      .update({ plan_tier: newTier })
      .eq("id", companyId);
    if (error) {
      toast.error("Erro ao alterar plano");
    } else {
      toast.success(`Plano alterado para ${newTier.toUpperCase()}`);
      setCompanies(prev => prev.map(c => c.id === companyId ? { ...c, plan_tier: newTier } : c));
      if (selectedCompany?.id === companyId) {
        setSelectedCompany(prev => prev ? { ...prev, plan_tier: newTier } : prev);
      }
    }
  };

  const filteredCompanies = companies.filter((c) => {
    const q = searchCompany.toLowerCase();
    return (
      c.name.toLowerCase().includes(q) ||
      (c.email || "").toLowerCase().includes(q) ||
      (c.cnpj || "").includes(q) ||
      (c.city || "").toLowerCase().includes(q)
    );
  });

  const filteredMembers = members.filter((m) => {
    const q = searchMember.toLowerCase();
    return (
      (m.profile?.full_name || "").toLowerCase().includes(q) ||
      (m.profile?.phone || "").includes(q) ||
      m.role.toLowerCase().includes(q)
    );
  });

  const companyMembers = selectedCompany
    ? members.filter((m) => m.company_id === selectedCompany.id)
    : [];

  const planStats = {
    free: companies.filter((c) => c.plan_tier === "free").length,
    pro: companies.filter((c) => c.plan_tier === "pro").length,
    premium: companies.filter((c) => c.plan_tier === "premium").length,
  };

  const formatDate = (d: string) =>
    new Date(d).toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric" });

  const getPlanBadge = (tier: string) => {
    const variants: Record<string, string> = {
      free: "bg-muted text-muted-foreground",
      pro: "bg-primary/10 text-primary",
      premium: "bg-accent text-accent-foreground",
    };
    return (
      <Badge className={variants[tier] || variants.free}>
        {tier.toUpperCase()}
      </Badge>
    );
  };

  if (loading || !isAdmin || hasPassword === null) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  // Password gate - if password exists and not unlocked
  if (hasPassword && !isUnlocked) {
    if (showRecovery) {
      return (
        <div className="flex items-center justify-center min-h-screen bg-background p-4">
          <Card className="w-full max-w-md">
            <CardHeader className="text-center">
              <div className="mx-auto w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-2">
                <KeyRound className="h-6 w-6 text-primary" />
              </div>
              <CardTitle>Recuperar Senha do Painel</CardTitle>
              <CardDescription>
                Confirme sua identidade com a senha de login da sua conta e defina uma nova senha para o painel admin.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Input
                type="password"
                placeholder="Sua senha de login (conta)"
                value={recoveryAuthPassword}
                onChange={(e) => setRecoveryAuthPassword(e.target.value)}
              />
              <Input
                type="password"
                placeholder="Nova senha do painel (mín. 6 caracteres)"
                value={recoveryNewPassword}
                onChange={(e) => setRecoveryNewPassword(e.target.value)}
              />
              <Input
                type="password"
                placeholder="Confirmar nova senha"
                value={recoveryConfirmPassword}
                onChange={(e) => setRecoveryConfirmPassword(e.target.value)}
              />
              <Button
                className="w-full gap-2"
                onClick={handleRecoverPassword}
                disabled={recovering || !recoveryAuthPassword.trim() || !recoveryNewPassword.trim()}
              >
                {recovering ? (
                  <RefreshCw className="h-4 w-4 animate-spin" />
                ) : (
                  <Save className="h-4 w-4" />
                )}
                Redefinir Senha do Painel
              </Button>
              <Button variant="ghost" className="w-full" onClick={() => setShowRecovery(false)}>
                Voltar
              </Button>
            </CardContent>
          </Card>
        </div>
      );
    }

    return (
      <div className="flex items-center justify-center min-h-screen bg-background p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="mx-auto w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-2">
              <Lock className="h-6 w-6 text-primary" />
            </div>
            <CardTitle>Painel Administrativo</CardTitle>
            <CardDescription>Digite a senha de acesso para continuar</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Input
              type="password"
              placeholder="Senha do painel admin"
              value={passwordInput}
              onChange={(e) => setPasswordInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleVerifyPassword()}
            />
            <Button
              className="w-full gap-2"
              onClick={handleVerifyPassword}
              disabled={verifyingPassword || !passwordInput.trim()}
            >
              {verifyingPassword ? (
                <RefreshCw className="h-4 w-4 animate-spin" />
              ) : (
                <KeyRound className="h-4 w-4" />
              )}
              Desbloquear
            </Button>
            <button
              type="button"
              className="w-full text-sm text-muted-foreground hover:text-foreground transition-colors"
              onClick={() => setShowRecovery(true)}
            >
              Esqueci minha senha
            </button>
            <Button variant="ghost" className="w-full" onClick={() => navigate("/")}>
              Voltar
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // First-time setup - no password set yet
  if (!hasPassword && isUnlocked) {
    // Show setup inline - will render main panel with setup banner
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center gap-3 flex-wrap">
          <Shield className="h-8 w-8 text-primary" />
          <div>
            <h1 className="text-2xl font-bold text-foreground">Painel Administrativo</h1>
            <p className="text-sm text-muted-foreground">Visão geral de todas as empresas e usuários</p>
          </div>
          <Badge variant="outline" className="ml-auto">Admin</Badge>
        </div>

        {/* Password Setup Banner */}
        {!hasPassword && (
          <Card className="border-primary/50 bg-primary/5">
            <CardContent className="pt-4 pb-4 px-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="h-5 w-5 text-primary mt-0.5" />
                <div className="flex-1 space-y-3">
                  <div>
                    <p className="font-semibold text-foreground">Defina uma senha para o painel admin</p>
                    <p className="text-sm text-muted-foreground">
                      Proteja o acesso ao painel com uma senha exclusiva. Sem ela, qualquer admin poderá acessar.
                    </p>
                  </div>
                  <div className="grid gap-2 max-w-sm">
                    <Input
                      type="password"
                      placeholder="Nova senha (mín. 6 caracteres)"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                    />
                    <Input
                      type="password"
                      placeholder="Confirmar senha"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                    />
                    <Button onClick={handleSetPassword} disabled={settingPassword} className="gap-2">
                      {settingPassword ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                      Definir Senha
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Change Password Toggle */}
        {hasPassword && (
          <div className="flex justify-end">
            <Button variant="outline" size="sm" className="gap-2" onClick={() => setShowChangePassword(!showChangePassword)}>
              <KeyRound className="h-3 w-3" />
              {showChangePassword ? "Cancelar" : "Alterar Senha Admin"}
            </Button>
          </div>
        )}

        {showChangePassword && hasPassword && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <KeyRound className="h-5 w-5" />
                Alterar Senha do Painel
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-2 max-w-sm">
                <Input
                  type="password"
                  placeholder="Nova senha (mín. 6 caracteres)"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                />
                <Input
                  type="password"
                  placeholder="Confirmar nova senha"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                />
                <Button onClick={handleSetPassword} disabled={settingPassword} className="gap-2">
                  {settingPassword ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                  Salvar Nova Senha
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* KPI Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-4 pb-3 px-4">
              <div className="flex items-center gap-2">
                <Building2 className="h-4 w-4 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">Empresas</span>
              </div>
              <p className="text-2xl font-bold text-foreground mt-1">{companies.length}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4 pb-3 px-4">
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">Usuários</span>
              </div>
              <p className="text-2xl font-bold text-foreground mt-1">{members.length}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4 pb-3 px-4">
              <div className="flex items-center gap-2">
                <Crown className="h-4 w-4 text-primary" />
                <span className="text-xs text-muted-foreground">PRO</span>
              </div>
              <p className="text-2xl font-bold text-primary mt-1">{planStats.pro}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4 pb-3 px-4">
              <div className="flex items-center gap-2">
                <Crown className="h-4 w-4 text-accent-foreground" />
                <span className="text-xs text-muted-foreground">Premium</span>
              </div>
              <p className="text-2xl font-bold text-foreground mt-1">{planStats.premium}</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="companies" className="w-full">
          <TabsList className="w-full grid grid-cols-4">
            <TabsTrigger value="companies">Empresas</TabsTrigger>
            <TabsTrigger value="members">Usuários</TabsTrigger>
            <TabsTrigger value="devices">Dispositivos</TabsTrigger>
            <TabsTrigger value="payments">Pagamentos</TabsTrigger>
          </TabsList>

          {/* Companies Tab */}
          <TabsContent value="companies" className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar empresa por nome, email, CNPJ ou cidade..."
                  value={searchCompany}
                  onChange={(e) => setSearchCompany(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Button variant="outline" size="icon" onClick={loadAllData} disabled={loadingData}>
                <RefreshCw className={`h-4 w-4 ${loadingData ? "animate-spin" : ""}`} />
              </Button>
            </div>

            <Card>
              <CardContent className="p-0">
                <Table>
                   <TableHeader>
                     <TableRow>
                       <TableHead>Empresa</TableHead>
                       <TableHead className="hidden md:table-cell">Cidade/UF</TableHead>
                       <TableHead>Plano</TableHead>
                       <TableHead className="hidden md:table-cell">Funcionários</TableHead>
                       <TableHead className="hidden md:table-cell">Serviços</TableHead>
                       <TableHead className="hidden md:table-cell">Cadastro</TableHead>
                       <TableHead className="text-right">Ações</TableHead>
                     </TableRow>
                   </TableHeader>
                   <TableBody>
                     {filteredCompanies.length === 0 ? (
                       <TableRow>
                         <TableCell colSpan={7} className="text-center text-muted-foreground py-8">
                           {loadingData ? "Carregando..." : "Nenhuma empresa encontrada"}
                         </TableCell>
                       </TableRow>
                     ) : (
                       filteredCompanies.map((c) => (
                         <TableRow key={c.id}>
                           <TableCell>
                             <div>
                               <p className="font-medium text-foreground">{c.name}</p>
                               {c.email && <p className="text-xs text-muted-foreground">{c.email}</p>}
                               {c.cnpj && <p className="text-xs text-muted-foreground">CNPJ: {c.cnpj}</p>}
                             </div>
                           </TableCell>
                           <TableCell className="hidden md:table-cell text-muted-foreground">
                             {[c.city, c.state].filter(Boolean).join("/") || "—"}
                           </TableCell>
                           <TableCell>{getPlanBadge(c.plan_tier)}</TableCell>
                           <TableCell className="hidden md:table-cell text-muted-foreground text-center">
                             {collaboratorCounts[c.id] || 0}
                           </TableCell>
                           <TableCell className="hidden md:table-cell text-muted-foreground text-center">
                             {serviceExecutionCounts[c.id] || 0}
                           </TableCell>
                           <TableCell className="hidden md:table-cell text-muted-foreground text-sm">
                             {formatDate(c.created_at)}
                           </TableCell>
                           <TableCell className="text-right">
                             <div className="flex items-center justify-end gap-1">
                               <select
                                 value={c.plan_tier}
                                 onChange={(e) => handleChangePlan(c.id, e.target.value as 'free' | 'pro' | 'premium')}
                                 className="text-xs border rounded px-2 py-1 bg-background text-foreground"
                               >
                                 <option value="free">FREE</option>
                                 <option value="pro">PRO</option>
                                 <option value="premium">PREMIUM</option>
                               </select>
                               <Button
                                 variant="ghost"
                                 size="sm"
                                 onClick={() => setSelectedCompany(selectedCompany?.id === c.id ? null : c)}
                               >
                                 <Eye className="h-4 w-4" />
                               </Button>
                             </div>
                           </TableCell>
                         </TableRow>
                       ))
                     )}
                   </TableBody>
                </Table>
              </CardContent>
            </Card>

            {/* Company Detail */}
            {selectedCompany && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">{selectedCompany.name}</CardTitle>
                  <CardDescription>Detalhes da empresa e membros</CardDescription>
                </CardHeader>
                 <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                    <div>
                      <p className="text-muted-foreground">CNPJ</p>
                      <p className="font-medium text-foreground">{selectedCompany.cnpj || "—"}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Email</p>
                      <p className="font-medium text-foreground">{selectedCompany.email || "—"}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Telefone</p>
                      <p className="font-medium text-foreground">{selectedCompany.phone || "—"}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground flex items-center gap-1"><MapPin className="h-3 w-3" /> Cidade/UF</p>
                      <p className="font-medium text-foreground">
                        {[selectedCompany.city, selectedCompany.state].filter(Boolean).join("/") || "—"}
                      </p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Plano</p>
                      {getPlanBadge(selectedCompany.plan_tier)}
                    </div>
                    <div>
                      <p className="text-muted-foreground flex items-center gap-1"><Calendar className="h-3 w-3" /> Data Instalação</p>
                      <p className="font-medium text-foreground">{formatDate(selectedCompany.created_at)}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground flex items-center gap-1"><Briefcase className="h-3 w-3" /> Funcionários</p>
                      <p className="font-medium text-foreground">{collaboratorCounts[selectedCompany.id] || 0}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground flex items-center gap-1"><ClipboardList className="h-3 w-3" /> Serviços Realizados</p>
                      <p className="font-medium text-foreground">{serviceExecutionCounts[selectedCompany.id] || 0}</p>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Membros ({companyMembers.length})</h4>
                    {companyMembers.length === 0 ? (
                      <p className="text-sm text-muted-foreground">Nenhum membro encontrado</p>
                    ) : (
                      <div className="space-y-2">
                        {companyMembers.map((m) => (
                          <div key={m.id} className="flex items-center justify-between p-2 rounded-lg border">
                            <div>
                              <p className="font-medium text-sm text-foreground">
                                {m.profile?.full_name || "Sem nome"}
                              </p>
                              <p className="text-xs text-muted-foreground">{m.profile?.phone || "—"}</p>
                            </div>
                            <Badge variant="outline">{m.role}</Badge>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Device Limit Override */}
                  <div className="border-t pt-4">
                    <h4 className="font-semibold text-foreground mb-3 flex items-center gap-2">
                      <Monitor className="h-4 w-4" /> Limites de Dispositivos
                    </h4>
                    <p className="text-xs text-muted-foreground mb-3">
                      Deixe vazio para usar o padrão do plano. Preencha para liberar dispositivos extras para esta empresa.
                    </p>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-xs text-muted-foreground flex items-center gap-1"><Monitor className="h-3 w-3" /> Max Computadores</label>
                        <Input
                          type="number"
                          min={1}
                          placeholder="Padrão do plano"
                          defaultValue={(selectedCompany as any)?.max_desktop_devices || ""}
                          onChange={async (e) => {
                            const val = parseInt(e.target.value) || null;
                            await supabase.from("companies").update({ max_desktop_devices: val } as any).eq("id", selectedCompany.id);
                            setCompanies(prev => prev.map(c => c.id === selectedCompany.id ? { ...c, max_desktop_devices: val } as any : c));
                          }}
                          className="h-8"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-muted-foreground flex items-center gap-1"><Smartphone className="h-3 w-3" /> Max Celulares</label>
                        <Input
                          type="number"
                          min={1}
                          placeholder="Padrão do plano"
                          defaultValue={(selectedCompany as any)?.max_mobile_devices || ""}
                          onChange={async (e) => {
                            const val = parseInt(e.target.value) || null;
                            await supabase.from("companies").update({ max_mobile_devices: val } as any).eq("id", selectedCompany.id);
                            setCompanies(prev => prev.map(c => c.id === selectedCompany.id ? { ...c, max_mobile_devices: val } as any : c));
                          }}
                          className="h-8"
                        />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Members Tab */}
          <TabsContent value="members" className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar usuário por nome, telefone ou role..."
                value={searchMember}
                onChange={(e) => setSearchMember(e.target.value)}
                className="pl-10"
              />
            </div>

            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Usuário</TableHead>
                      <TableHead>Empresa</TableHead>
                      <TableHead className="hidden md:table-cell">Cidade/UF</TableHead>
                      <TableHead>Role</TableHead>
                      <TableHead className="hidden md:table-cell">Telefone</TableHead>
                      <TableHead className="hidden md:table-cell">Funcionários</TableHead>
                      <TableHead className="hidden md:table-cell">Serviços</TableHead>
                      <TableHead className="hidden md:table-cell">Desde</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredMembers.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={8} className="text-center text-muted-foreground py-8">
                          Nenhum usuário encontrado
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredMembers.map((m) => {
                        const company = companies.find(c => c.id === m.company_id);
                        return (
                          <TableRow key={m.id}>
                            <TableCell>
                              <p className="font-medium text-foreground">{m.profile?.full_name || "Sem nome"}</p>
                            </TableCell>
                            <TableCell>
                              <div>
                                <p className="text-sm text-foreground">{company?.name || "—"}</p>
                                {company && getPlanBadge(company.plan_tier)}
                              </div>
                            </TableCell>
                            <TableCell className="hidden md:table-cell text-muted-foreground">
                              {company ? [company.city, company.state].filter(Boolean).join("/") || "—" : "—"}
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline">{m.role}</Badge>
                            </TableCell>
                            <TableCell className="hidden md:table-cell text-muted-foreground">
                              {m.profile?.phone || "—"}
                            </TableCell>
                            <TableCell className="hidden md:table-cell text-muted-foreground text-center">
                              {collaboratorCounts[m.company_id] || 0}
                            </TableCell>
                            <TableCell className="hidden md:table-cell text-muted-foreground text-center">
                              {serviceExecutionCounts[m.company_id] || 0}
                            </TableCell>
                            <TableCell className="hidden md:table-cell text-muted-foreground text-sm">
                              {formatDate(m.created_at)}
                            </TableCell>
                          </TableRow>
                        );
                      })
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Devices Tab */}
          <TabsContent value="devices" className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar por empresa, dispositivo ou tipo..."
                  value={searchDevice}
                  onChange={(e) => setSearchDevice(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Button variant="outline" size="icon" onClick={loadAllData} disabled={loadingData}>
                <RefreshCw className={`h-4 w-4 ${loadingData ? "animate-spin" : ""}`} />
              </Button>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <Card>
                <CardContent className="pt-4 pb-3 px-4">
                  <div className="flex items-center gap-2">
                    <Smartphone className="h-4 w-4 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">Celulares Ativos</span>
                  </div>
                  <p className="text-2xl font-bold text-foreground mt-1">
                    {deviceSessions.filter(d => d.is_active && d.device_type === "mobile").length}
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-4 pb-3 px-4">
                  <div className="flex items-center gap-2">
                    <Monitor className="h-4 w-4 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">Computadores Ativos</span>
                  </div>
                  <p className="text-2xl font-bold text-foreground mt-1">
                    {deviceSessions.filter(d => d.is_active && d.device_type === "desktop").length}
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-4 pb-3 px-4">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="h-4 w-4 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">Total Sessões</span>
                  </div>
                  <p className="text-2xl font-bold text-foreground mt-1">{deviceSessions.length}</p>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Dispositivo</TableHead>
                      <TableHead>Empresa</TableHead>
                      <TableHead className="hidden md:table-cell">Tipo</TableHead>
                      <TableHead className="hidden md:table-cell">Último Acesso</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {(() => {
                      const q = searchDevice.toLowerCase();
                      const filtered = deviceSessions.filter(d => {
                        const companyName = companies.find(c => c.id === d.company_id)?.name || "";
                        return (
                          (d.device_name || "").toLowerCase().includes(q) ||
                          companyName.toLowerCase().includes(q) ||
                          d.device_type.toLowerCase().includes(q) ||
                          d.device_id.toLowerCase().includes(q)
                        );
                      });
                      if (filtered.length === 0) {
                        return (
                          <TableRow>
                            <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                              Nenhum dispositivo encontrado
                            </TableCell>
                          </TableRow>
                        );
                      }
                      return filtered.map(d => {
                        const company = companies.find(c => c.id === d.company_id);
                        return (
                          <TableRow key={d.id}>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                {d.device_type === "mobile" ? <Smartphone className="h-4 w-4 text-muted-foreground" /> : <Monitor className="h-4 w-4 text-muted-foreground" />}
                                <div>
                                  <p className="font-medium text-foreground text-sm">{d.device_name || "Dispositivo"}</p>
                                  <p className="text-xs text-muted-foreground font-mono">{d.device_id.slice(0, 8)}...</p>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <p className="text-sm text-foreground">{company?.name || "—"}</p>
                              {company && getPlanBadge(company.plan_tier)}
                            </TableCell>
                            <TableCell className="hidden md:table-cell text-muted-foreground text-sm capitalize">{d.device_type}</TableCell>
                            <TableCell className="hidden md:table-cell text-muted-foreground text-sm">
                              {new Date(d.last_active_at).toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit", year: "2-digit", hour: "2-digit", minute: "2-digit" })}
                            </TableCell>
                            <TableCell>
                              {d.is_active ? (
                                <Badge className="bg-green-500/10 text-green-600 border-green-500/20">Ativo</Badge>
                              ) : (
                                <Badge variant="secondary">Revogado</Badge>
                              )}
                            </TableCell>
                            <TableCell className="text-right">
                              {d.is_active ? (
                                <Button
                                  variant="destructive"
                                  size="sm"
                                  onClick={async () => {
                                    const { error } = await supabase
                                      .from("device_sessions")
                                      .update({ is_active: false })
                                      .eq("id", d.id);
                                    if (error) {
                                      toast.error("Erro ao revogar dispositivo");
                                    } else {
                                      toast.success("Dispositivo revogado");
                                      setDeviceSessions(prev => prev.map(s => s.id === d.id ? { ...s, is_active: false } : s));
                                    }
                                  }}
                                >
                                  Revogar
                                </Button>
                              ) : (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={async () => {
                                    const { error } = await supabase
                                      .from("device_sessions")
                                      .update({ is_active: true })
                                      .eq("id", d.id);
                                    if (error) {
                                      toast.error("Erro ao reativar dispositivo");
                                    } else {
                                      toast.success("Dispositivo reativado");
                                      setDeviceSessions(prev => prev.map(s => s.id === d.id ? { ...s, is_active: true } : s));
                                    }
                                  }}
                                >
                                  Reativar
                                </Button>
                              )}
                            </TableCell>
                          </TableRow>
                        );
                      });
                    })()}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Payments Tab */}
          <TabsContent value="payments" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <CreditCard className="h-5 w-5 text-primary" />
                  <CardTitle>Mercado Pago</CardTitle>
                </div>
                <CardDescription>Gateway de pagamento para assinaturas e cobrançass</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center gap-2 p-3 rounded-lg bg-muted">
                  <CheckCircle className="h-4 w-4 text-primary" />
                  <span className="text-sm font-medium">Credenciais configuradas com segurança no servidor</span>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <Webhook className="h-4 w-4 text-muted-foreground" />
                    <h3 className="font-semibold text-foreground">Configuração do Webhook</h3>
                  </div>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <p>Para receber notificações de pagamento em tempo real:</p>
                    <ol className="list-decimal list-inside space-y-1 ml-2">
                      <li>Acesse <strong>Suas integrações</strong> no painel do Mercado Pago</li>
                      <li>Selecione sua aplicação e vá em <strong>Webhooks</strong></li>
                      <li>Adicione a URL abaixo como URL de notificação</li>
                      <li>Selecione os eventos: <strong>payment</strong></li>
                    </ol>
                  </div>
                  <div className="flex items-center gap-2 p-3 rounded-lg border bg-card">
                    <code className="flex-1 text-xs break-all font-mono text-foreground">{webhookUrl}</code>
                    <Button size="sm" variant="outline" onClick={copyWebhookUrl}>Copiar</Button>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    className="gap-2"
                    onClick={() => window.open("https://www.mercadopago.com.br/developers/panel/app", "_blank")}
                  >
                    <ExternalLink className="h-3 w-3" />
                    Abrir painel Mercado Pago
                  </Button>
                </div>

                <div className="space-y-4 border-t pt-4">
                  <h3 className="font-semibold text-foreground flex items-center gap-2">
                    <AlertCircle className="h-4 w-4 text-muted-foreground" />
                    Credenciais do Gateway
                  </h3>
                  <p className="text-xs text-muted-foreground">
                    Encontre suas credenciais em{" "}
                    <a
                      href="https://www.mercadopago.com.br/developers/panel/app"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary underline"
                    >
                      Suas integrações → Credenciais
                    </a>
                  </p>

                  <div className="grid gap-4 md:grid-cols-2">
                    {/* Access Token */}
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-foreground">Access Token (Secret)</label>
                      {mpAccessTokenSet && (
                        <p className="text-xs text-muted-foreground font-mono">
                          Atual: {mpAccessTokenPreview}
                        </p>
                      )}
                      <Input
                        type="password"
                        placeholder="APP_USR-..."
                        value={mpAccessToken}
                        onChange={(e) => setMpAccessToken(e.target.value)}
                      />
                      <p className="text-xs text-muted-foreground">Token privado para processar pagamentos</p>
                      {mpAccessTokenSet ? (
                        <Badge variant="secondary" className="text-xs">✓ Configurado</Badge>
                      ) : (
                        <Badge variant="destructive" className="text-xs">Não configurado</Badge>
                      )}
                    </div>

                    {/* Public Key */}
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-foreground">Public Key</label>
                      {mpPublicKeySet && (
                        <p className="text-xs text-muted-foreground font-mono">
                          Atual: {mpPublicKeyPreview}
                        </p>
                      )}
                      <Input
                        placeholder="APP_USR-..."
                        value={mpPublicKey}
                        onChange={(e) => setMpPublicKey(e.target.value)}
                      />
                      <p className="text-xs text-muted-foreground">Chave pública para o checkout</p>
                      {mpPublicKeySet ? (
                        <Badge variant="secondary" className="text-xs">✓ Configurado</Badge>
                      ) : (
                        <Badge variant="destructive" className="text-xs">Não configurado</Badge>
                      )}
                    </div>
                  </div>

                  <Button
                    onClick={saveCredentials}
                    disabled={savingCredentials || (!mpAccessToken && !mpPublicKey)}
                    className="gap-2"
                  >
                    {savingCredentials ? (
                      <RefreshCw className="h-4 w-4 animate-spin" />
                    ) : (
                      <Save className="h-4 w-4" />
                    )}
                    Salvar Credenciais
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <Button variant="ghost" onClick={() => navigate("/")}>
          Voltar ao início
        </Button>
      </div>
    </div>
  );
}
